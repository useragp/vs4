"""Core component vs. its plugins / extensions / add-ins - for every product, not only Python.

Descriptions and CNA records below are modelled on real 2026 NVD / CVE.org records."""
import datetime as dt
import os
import sys
import tempfile
import time
import unittest
from unittest import mock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from vulnscan.matcher import (assess_nvd, cpe_matches_component, extension_name,  # noqa: E402
                              extension_phrases, text_scope)
from vulnscan.models import Component  # noqa: E402
from vulnscan.scanner import ScanOptions, Scanner  # noqa: E402
from vulnscan.versions import parse_cpe  # noqa: E402

JENKINS = Component(name="Jenkins", version="2.479.1", vendor="Jenkins project", keywords=["Jenkins"],
                    cpe=["cpe:2.3:a:jenkins:jenkins:2.479.1:*:*:*:lts:*:*:*"], id="jenkins")
VSCODE = Component(name="Visual Studio Code", version="1.90.0", vendor="Microsoft",
                   keywords=["Visual Studio Code", "VS Code"],
                   cpe=["cpe:2.3:a:microsoft:visual_studio_code:1.90.0:*:*:*:*:*:*:*"], id="vscode")
GIT_NOCPE = Component(name="Git", version="2.39.2", vendor="Git project", keywords=["Git"], id="gitnocpe")
GIT = Component(name="Git", version="2.39.2", vendor="Git project", keywords=["Git"],
                cpe=["cpe:2.3:a:git-scm:git:2.39.2:*:*:*:*:*:*:*"], id="git")
BASH = Component(name="Bash", version="5.1", vendor="GNU", keywords=["GNU Bash"],
                 cpe=["cpe:2.3:a:gnu:bash:5.1:*:*:*:*:*:*:*"], id="bash")
EA = Component(name="Enterprise Architect", version="16.1", vendor="Sparx Systems",
               keywords=["Enterprise Architect"], id="ea")
JAZZ = Component(name="IBM Jazz", version="7.0.3", vendor="IBM", keywords=["Jazz", "Jazz Team Server"], id="jazz")


def nvd(cve_id, desc, configurations=None, status="Awaiting Analysis"):
    return {"id": cve_id, "description": desc, "published": "2026-09-01T10:00:00.000",
            "last_modified": "2026-09-05T10:00:00.000", "nvd_status": status, "cvss_score": 7.5,
            "cvss_vector": "", "cvss_version": "3.1", "severity_hint": "HIGH", "cwes": set(),
            "references": [], "configurations": configurations or [], "kev": False, "kev_date_added": ""}


def cfg(criteria, **rng):
    m = {"criteria": criteria, "vulnerable": True}
    m.update(rng)
    return [{"nodes": [{"cpeMatch": [m]}]}]


class PluginScopeTests(unittest.TestCase):
    # ---------------------------------------------------------------- Jenkins
    def test_jenkins_core_vs_plugin(self):
        core = nvd("CVE-2026-117615", "Jenkins 2.587 and earlier, LTS 2.580.1 and earlier follows symbolic links "
                   "when copying the directory of an item being renamed.",
                   cfg("cpe:2.3:a:jenkins:jenkins:*:*:*:*:lts:*:*:*", versionEndExcluding="2.580.2"), "Analyzed")
        a = assess_nvd(core, JENKINS, "keyword", "Jenkins")
        self.assertEqual((a.applicability, a.scope), ("HIGH", "core"))

        plugin_cna = [{"vendor": "Jenkins Project", "product": "Jenkins Multijob Plugin",
                       "versions": [{"version": "0", "lessThanOrEqual": "669.v9d96a_d9c71b_0", "status": "affected"}]}]
        p = nvd("CVE-2026-70432", "A cross-site request forgery (CSRF) vulnerability in Jenkins Multijob Plugin "
                "669.v9d96a_d9c71b_0 and earlier allows attackers to execute arbitrary code.")
        a = assess_nvd(p, JENKINS, "keyword", "Jenkins", cna=lambda i: plugin_cna)
        self.assertEqual((a.applicability, a.scope), ("LOW", "ecosystem"))
        # same CVE without CNA data: the text alone identifies the plugin
        a = assess_nvd(p, JENKINS, "keyword", "Jenkins")
        self.assertEqual(a.scope, "ecosystem")

    def test_jenkins_plugin_by_cpe_target_sw(self):
        plugin = cfg("cpe:2.3:a:jenkins:pipeline\\:_groovy:*:*:*:*:jenkins:*:*", versionEndIncluding="3990.vd281dd77a_388")
        p = nvd("CVE-2026-1", "Jenkins Pipeline: Groovy Plugin 3990.vd281dd77a_388 and earlier allows sandbox bypass.",
                plugin, "Analyzed")
        a = assess_nvd(p, JENKINS, "keyword", "Jenkins")
        self.assertEqual((a.applicability, a.scope), ("LOW", "ecosystem"))
        # Jenkins "git" plugin is not Git - even for a Git component without a CPE (name-only match)
        git_plugin = parse_cpe("cpe:2.3:a:jenkins:git:*:*:*:*:*:jenkins:*:*")
        self.assertFalse(cpe_matches_component(git_plugin, GIT_NOCPE))
        p = nvd("CVE-2026-2", "Jenkins Git Plugin 5.2.1 and earlier does not escape the repository URL.",
                cfg("cpe:2.3:a:jenkins:git:*:*:*:*:*:jenkins:*:*", versionEndIncluding="5.2.1"), "Analyzed")
        for comp in (GIT, GIT_NOCPE):
            a = assess_nvd(p, comp, "keyword", "Git")
            self.assertNotEqual(a.scope, "core", comp.id)

    def test_jenkins_other_vendor_tool_is_not_core(self):
        cna = [{"vendor": "Jenkins Project", "product": "Jenkins update-center2",
                "versions": [{"version": "0", "lessThanOrEqual": "3.18.3", "status": "affected"}]}]
        p = nvd("CVE-2026-84677", "Jenkins update-center2 3.18.3 and earlier does not escape plugin-provided values "
                "on plugin download index pages, resulting in a stored cross-site scripting vulnerability.")
        a = assess_nvd(p, JENKINS, "keyword", "Jenkins", cna=lambda i: cna)
        self.assertNotEqual(a.scope, "core")

    # ---------------------------------------------------------------- VS Code
    def test_vscode_core_vs_extensions(self):
        core = nvd("CVE-2026-59113", "Missing authorization in Visual Studio Code allows an unauthorized attacker to "
                   "execute code over a network.",
                   cfg("cpe:2.3:a:microsoft:visual_studio_code:*:*:*:*:*:*:*:*", versionEndExcluding="1.132.1"),
                   "Analyzed")
        self.assertEqual(assess_nvd(core, VSCODE, "keyword", "Visual Studio Code").scope, "core")
        # CNA lists the product as "Visual Studio Code", but it is an extension
        cna = [{"vendor": "Microsoft", "product": "Visual Studio Code", "defaultStatus": "unaffected",
                "versions": [{"version": "1.0.0", "lessThan": "1.145.3", "status": "affected"}]}]
        p = nvd("CVE-2026-119976", "External control of file name or path in Visual Studio Code - GitHub Pull "
                "Requests and Issues Extension allows an unauthorized attacker to disclose information.")
        a = assess_nvd(p, VSCODE, "keyword", "Visual Studio Code", cna=lambda i: cna)
        self.assertEqual((a.applicability, a.scope), ("LOW", "ecosystem"))
        # third-party extension with target_sw = visual_studio_code
        p = nvd("CVE-2026-84967", "A component of the MongoDB extension for Visual Studio Code does not neutralize "
                "special characters in a connection string.",
                cfg("cpe:2.3:a:mongodb:mongodb:*:*:*:*:*:visual_studio_code:*:*", versionEndExcluding="1.14.0"),
                "Analyzed")
        a = assess_nvd(p, VSCODE, "keyword", "Visual Studio Code")
        self.assertEqual((a.applicability, a.scope), ("LOW", "ecosystem"))
        # VS Code "extension host" is a feature of VS Code itself, not an extension
        self.assertEqual(extension_phrases("Visual Studio Code extension host allows code execution",
                                           ["Visual Studio Code"]), [])

    def test_vendor_product_with_other_suffix(self):
        remote = parse_cpe("cpe:2.3:a:microsoft:visual_studio_code_remote_development:*:*:*:*:*:*:*:*")
        nocpe = Component(name="Visual Studio Code", version="1.90.0", vendor="Microsoft")
        self.assertFalse(cpe_matches_component(remote, nocpe))
        jlink = Component(name="J-Link", version="7.88", vendor="SEGGER")
        self.assertTrue(cpe_matches_component(
            parse_cpe("cpe:2.3:a:segger:j-link_software_and_documentation_pack:*:*:*:*:*:*:*:*"), jlink))

    # ---------------------------------------------------------------- Git / Bash
    def test_git_other_products(self):
        p = nvd("CVE-2026-109318", "Grav Git Sync 1.0.2 through 3.4.12 contains a command injection vulnerability.")
        self.assertNotEqual(assess_nvd(p, GIT, "keyword", "Git").scope, "core")
        p = nvd("CVE-2026-84502", "A flaw was found in Red Hat Ansible Automation Platform. A git project URL "
                "such as --upload-pack is interpreted by git as an option.")
        a = assess_nvd(p, GIT, "keyword", "Git")
        self.assertIsNone(a.applicability)      # 'git project' is not vendor evidence
        p = nvd("CVE-2026-3", "Git LFS before 3.6.1 allows a malicious repository to write files outside the "
                "working tree.")
        self.assertEqual(text_scope(p["description"], GIT, ["Git"])[0], "ecosystem")

    def test_bash_core_vs_addons(self):
        p = nvd("CVE-2026-4", "bash-completion before 2.12 evaluates a crafted file name in the git completion.")
        self.assertNotEqual(assess_nvd(p, BASH, "keyword", "Bash").scope, "core")
        p = nvd("CVE-2026-73036", "Bash-it 3.2.0 contains a terminal escape sequence injection vulnerability in "
                "the barbuk theme.")
        self.assertNotEqual(assess_nvd(p, BASH, "keyword", "Bash").scope, "core")
        p = nvd("CVE-2026-5", "GNU Bash before 5.1.8 mishandles the expansion of a crafted prompt string.")
        a = assess_nvd(p, BASH, "keyword", "GNU Bash")
        self.assertEqual((a.applicability, a.scope), ("MEDIUM", "core"))
        # an environment variable name is not a Bash add-on
        p = nvd("CVE-2026-84706", "The injector omits process-hijacking loader variables such as BASH_ENV.")
        self.assertNotEqual(text_scope(p["description"], BASH, ["Bash"])[0], "ecosystem")

    # ---------------------------------------------------------------- Enterprise Architect / IBM Jazz
    def test_enterprise_architect(self):
        core = nvd("CVE-2026-6", "Sparx Systems Enterprise Architect before 16.1.1628 allows XSS in the model "
                   "browser.")
        a = assess_nvd(core, EA, "keyword", "Enterprise Architect")
        self.assertEqual((a.applicability, a.scope), ("MEDIUM", "core"))
        addin = nvd("CVE-2026-7", "The eaDocX add-in for Sparx Enterprise Architect 6.1 allows SQL injection.")
        self.assertEqual(assess_nvd(addin, EA, "keyword", "Enterprise Architect", strict=False).scope, "ecosystem")
        pcs = nvd("CVE-2026-8", "Sparx Systems Pro Cloud Server before 6.0.165 (WebEA) allows XSS.")
        self.assertNotEqual(assess_nvd(pcs, EA, "keyword", "Enterprise Architect").scope, "core")

    def test_ibm_jazz(self):
        other = nvd("CVE-2026-9", "IBM Jazz for Service Management 1.1.3.20 could allow a remote attacker to "
                    "obtain sensitive information.")
        self.assertNotEqual(assess_nvd(other, JAZZ, "keyword", "Jazz").scope, "core")
        core = nvd("CVE-2026-10", "IBM Jazz Team Server 7.0.2 and 7.0.3 is vulnerable to cross-site scripting.")
        self.assertEqual(assess_nvd(core, JAZZ, "keyword", "Jazz").scope, "core")

    def test_extension_name(self):
        self.assertTrue(extension_name("Jenkins Credentials Binding Plugin"))
        self.assertTrue(extension_name("GitLens extension"))
        self.assertFalse(extension_name("Jenkins plugin manager"))
        self.assertFalse(extension_name("Visual Studio Code"))

    # ---------------------------------------------------------------- scanner option
    def test_core_scope_hides_unconfirmed_scope(self):
        """Default 'core' shows ONLY confirmed core matches; 'Core + ecosystem' adds the rest."""
        def fake_search(self_, params, start, end, flags=(), date_field="published"):
            def raw(cid, desc):
                return {"id": cid, "published": "2026-09-01T00:00:00.000", "lastModified": "2026-09-02T00:00:00.000",
                        "vulnStatus": "Awaiting Analysis", "descriptions": [{"lang": "en", "value": desc}],
                        "metrics": {}, "configurations": [], "references": []}
            if params.get("keywordSearch") == "Jenkins":
                return iter([raw("CVE-2026-9001", "Jenkins 2.587 and earlier, LTS 2.580.1 and earlier allows XSS."),
                             raw("CVE-2026-9002", "Jenkins Credentials Binding Plugin 1.2 and earlier masks secrets "
                                                  "incorrectly."),
                             raw("CVE-2026-9003", "Some tool mentions Jenkins once.")])
            return iter([])
        with tempfile.TemporaryDirectory() as out:
            def run(scope):
                opts = ScanOptions(start_date=dt.date(2026, 8, 1), end_date=dt.date(2026, 11, 26), output_dir=out,
                                   use_nvd_cpe=False, use_osv=False, use_kev=False, use_cve_org=False, strict=False,
                                   scope=scope, formats=("json",))
                with mock.patch("vulnscan.sources.NVDClient.search_cves", fake_search):
                    res = Scanner([JENKINS], opts, log=lambda m: None).run()
                return {v.id: v.applicability for v in res.vulnerabilities}
            self.assertEqual(run("core"), {"CVE-2026-9001": "MEDIUM"})
            time.sleep(1.1)
            self.assertEqual(run("ecosystem"), {"CVE-2026-9001": "MEDIUM", "CVE-2026-9002": "LOW",
                                                "CVE-2026-9003": "LOW"})


if __name__ == "__main__":
    unittest.main()
